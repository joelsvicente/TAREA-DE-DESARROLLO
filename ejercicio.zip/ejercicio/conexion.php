<?php
$servername = "localhost:3306";
$username = "root";
$password = "joel2024";
$dbname = "bdempresa";

$conexion = new mysqli($servername,$username,$password,$dbname);

if ($conexion->connect_error){
    die("Error de conexión:  " . $conexion->connect_error);
} else{
    echo("conexion establecida hoy");
}