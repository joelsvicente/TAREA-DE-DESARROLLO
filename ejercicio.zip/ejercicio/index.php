<?php
session_start();
require_once 'conexion.php';


// Función para validar el cliente
function validarCliente($codigo, $password, $conexion) {
    $stmt = $conexion->prepare("SELECT * FROM bp_clientes WHERE codigo = ? AND password = ?");
    $stmt->bind_param("ss", $codigo, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return true;
    } else {
        return false;
    }
}

// Función para cerrar sesión
if (isset($_GET['action']) && $_GET['action'] == 'logout') { 
    session_unset();  // Liberar todas las variables de sesión
    session_destroy();  // Destruir la sesión
    header("Location: " . $_SERVER['PHP_SELF']);  // Redirigir a la página de inicio de sesión 
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $codigo = $_POST['codigo'];
    $password = $_POST['password'];

    if (validarCliente($codigo, $password, $conexion)) {
        $_SESSION['cliente'] = $codigo;
    } else {
        echo "Cliente no cuenta con accesos.";
        exit;
    }
}

// Si el cliente ya está autenticado
if (isset($_SESSION['cliente'])) {
    echo "<a  href='?action=logout'>Cerrar Sesión</a><br><br>";
  
    $filtro = '';
    
    if (isset($_POST['buscar'])) {
        $buscar = $_POST['buscar'];
        $filtro = " AND (descripcion LIKE '%" . $conn->real_escape_string($buscar) . "%' OR codigo LIKE '%" . $conn->real_escape_string($buscar) . "%')";
    }

    $query = "SELECT * FROM bp_productos WHERE oferta = 'S' $filtro ORDER BY descripcion";
    $result = $conexion->query($query);
    
    if ($result->num_rows > 0) {
        echo "<h2>Productos en oferta</h2>";
        echo "<table border='1'>";
        echo "<tr><th>Código</th><th>Descripción</th><th>Precio Venta</th><th>Precio Oferta</th></tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['codigo'] . "</td>";
            echo "<td>" . $row['descripcion'] . "</td>";
            echo "<td>" . $row['precio_venta'] . "</td>";
            echo "<td>" . $row['precio_oferta'] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
        ?>
             <form href='?action=logout'>
                  <input type="submit" value="Cerrar Sesion" action="logout>
             </form>
        <?php
    } else {
        echo "No hay productos en oferta.";
    }
} else {
    // Formulario de inicio de sesión
    ?>
    <h2>Iniciar Sesión</h2>
    <form method="POST" action="">
        <label>Código:</label>
        <input type="text" name="codigo" required><br>
        <label>Password:</label>
        <input type="password" name="password" required><br>
        <input type="submit" value="Ingresar">
    </form>
    <?php
}
?>